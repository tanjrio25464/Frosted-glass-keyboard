package com.example.frostedglasskeyboard

import android.inputmethodservice.InputMethodService
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.textservice.SentenceSuggestionsInfo
import android.view.textservice.SpellCheckerSession
import android.view.textservice.SuggestionsInfo
import android.view.textservice.TextInfo
import android.view.textservice.TextServicesManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class GlassKeyboardService : InputMethodService(),
    SpellCheckerSession.SpellCheckerSessionListener {

    private lateinit var root: LinearLayout
    private lateinit var suggestionRow: LinearLayout
    private var spellSession: SpellCheckerSession? = null
    private var currentWord = ""
    private var suggestions = mutableListOf<String>()
    private var shifted = false
    private var predictionsAllowed = true
    private var pendingSpellWord = ""

    private val nextWords = mapOf(
        "hello" to listOf("there", "how", "again"),
        "how" to listOf("are", "is", "do"),
        "are" to listOf("you", "we", "they"),
        "i" to listOf("am", "think", "have"),
        "you" to listOf("are", "can", "have"),
        "what" to listOf("is", "are", "do"),
        "the" to listOf("best", "same", "one"),
        "this" to listOf("is", "looks", "was"),
        "it" to listOf("is", "was", "looks"),
        "good" to listOf("morning", "idea", "one"),
        "thank" to listOf("you", "you!"),
        "see" to listOf("you", "that", "what"),
        "have" to listOf("a", "you", "been"),
        "what's" to listOf("up", "that", "happening")
    )

    override fun onCreate() {
        super.onCreate()
        createSpellChecker()
    }

    private fun createSpellChecker() {
        val manager = getSystemService(TEXT_SERVICES_MANAGER_SERVICE) as? TextServicesManager
        spellSession = manager?.newSpellCheckerSession(
            null, Locale("en", "IE"), this, true
        )
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        val inputType = attribute?.inputType ?: EditorInfo.TYPE_CLASS_TEXT
        val variation = inputType and EditorInfo.TYPE_MASK_VARIATION
        val isPassword = variation == EditorInfo.TYPE_TEXT_VARIATION_PASSWORD ||
            variation == EditorInfo.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
            variation == EditorInfo.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
            variation == EditorInfo.TYPE_NUMBER_VARIATION_PASSWORD

        predictionsAllowed = !isPassword &&
            (inputType and EditorInfo.TYPE_MASK_CLASS) != EditorInfo.TYPE_CLASS_NUMBER

        currentWord = ""
        pendingSpellWord = ""
        suggestions.clear()
        if (::suggestionRow.isInitialized) renderSuggestions()
    }

    override fun onCreateInputView(): View {
        val dark = (resources.configuration.uiMode and
            Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

        val panelColor = if (dark) Color.argb(226, 24, 25, 28)
                         else Color.argb(226, 239, 241, 244)
        val keyColor = if (dark) Color.argb(205, 67, 69, 74)
                       else Color.argb(205, 255, 255, 255)
        val textColor = if (dark) Color.WHITE else Color.rgb(35, 37, 42)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7), dp(7), dp(7), dp(8))
            background = rounded(panelColor, 25)
        }

        suggestionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(5))
        }
        root.addView(suggestionRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(38)
        ))
        renderSuggestions()

        val rows = listOf(
            "qwertyuiop",
            "asdfghjkl",
            "⇧zxcvbnm⌫"
        )

        rows.forEachIndexed { index, letters ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            val rowParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(49)
            ).apply { bottomMargin = dp(5) }
            root.addView(row, rowParams)

            if (index == 1) {
                row.setPadding(dp(12), 0, dp(12), 0)
            }
            letters.forEach { char ->
                val label = if (shifted && char.isLetter()) char.uppercaseChar().toString()
                            else char.toString()
                val weight = if (char == '⇧' || char == '⌫') 1.35f else 1f
                addKey(row, label, keyColor, textColor, weight) {
                    when (char) {
                        '⇧' -> {
                            shifted = !shifted
                            refreshLetterKeys()
                        }
                        '⌫' -> deleteOneCharacter()
                        else -> {
                            commit(label)
                            if (shifted) {
                                shifted = false
                                refreshLetterKeys()
                            }
                        }
                    }
                }
            }
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        root.addView(bottom, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(48)
        ))

        addKey(bottom, "?123", keyColor, textColor, 1.2f) {
            // Number/symbol layout can be added here.
        }
        addKey(bottom, ",", keyColor, textColor, 0.8f) { commit(",") }
        addKey(bottom, "☺", keyColor, textColor, 0.8f) {
            // Opens the system emoji keyboard only if the editor supports it.
            currentInputConnection?.commitText("☺", 1)
        }
        addKey(bottom, "English (IE)", keyColor, textColor, 4f) { commit(" ") }
        addKey(bottom, ".", keyColor, textColor, 0.8f) { commit(".") }
        addKey(bottom, "↵", keyColor, textColor, 1.1f) { sendEnter() }

        return root
    }

    private fun addKey(
        row: LinearLayout,
        label: String,
        keyColor: Int,
        textColor: Int,
        weight: Float,
        action: () -> Unit
    ) {
        val button = TextView(this).apply {
            text = label
            textSize = if (label.length > 2) 12f else 20f
            setTextColor(textColor)
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            background = rounded(keyColor, 13)
            isClickable = true
            isFocusable = true
            setOnClickListener { action() }
            elevation = dp(1).toFloat()
        }
        val params = LinearLayout.LayoutParams(0, dp(45), weight).apply {
            marginStart = dp(2)
            marginEnd = dp(2)
        }
        row.addView(button, params)
    }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), if (Color.alpha(color) > 0)
                Color.argb(35, 255, 255, 255) else Color.TRANSPARENT)
        }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun commit(value: String) {
        currentInputConnection?.commitText(value, 1)
        updatePredictionState()
    }

    private fun deleteOneCharacter() {
        val connection = currentInputConnection ?: return
        connection.deleteSurroundingText(1, 0)
        updatePredictionState()
    }

    private fun sendEnter() {
        val connection = currentInputConnection ?: return
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
            ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE &&
            action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            connection.performEditorAction(action)
        } else {
            connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            connection.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }

    private fun updatePredictionState() {
        if (!predictionsAllowed) {
            suggestions.clear()
            renderSuggestions()
            return
        }

        val before = currentInputConnection?.getTextBeforeCursor(80, 0)?.toString().orEmpty()
        currentWord = before.takeLastWhile { it.isLetter() || it == '\'' }

        if (currentWord.isNotBlank()) {
            pendingSpellWord = currentWord
            suggestions = mutableListOf(currentWord)
            renderSuggestions()
            spellSession?.getSuggestions(TextInfo(currentWord), 5)
        } else {
            pendingSpellWord = ""
            val previous = before.trimEnd().substringAfterLast(' ')
                .lowercase(Locale.getDefault())
            suggestions = (nextWords[previous] ?: emptyList()).toMutableList()
            renderSuggestions()
        }
    }

    private fun renderSuggestions() {
        if (!::suggestionRow.isInitialized) return
        suggestionRow.removeAllViews()
        if (!predictionsAllowed) return

        val shown = suggestions.distinct().take(3)
        if (shown.isEmpty()) {
            addSuggestionButton(" ")
            return
        }
        shown.forEach { addSuggestionButton(it) }
    }

    private fun addSuggestionButton(word: String) {
        val dark = (resources.configuration.uiMode and
            Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val color = if (dark) Color.WHITE else Color.DKGRAY
        val item = TextView(this).apply {
            text = word
            textSize = 14f
            setTextColor(color)
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            setOnClickListener {
                if (word.isNotBlank()) replaceCurrentWord(word)
            }
        }
        suggestionRow.addView(item, LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.MATCH_PARENT, 1f
        ))
    }

    private fun replaceCurrentWord(replacement: String) {
        val connection = currentInputConnection ?: return
        val before = connection.getTextBeforeCursor(100, 0)?.toString().orEmpty()
        val word = before.takeLastWhile { it.isLetter() || it == '\'' }
        if (word.isNotEmpty()) {
            connection.deleteSurroundingText(word.length, 0)
        }
        connection.commitText("$replacement ", 1)
        updatePredictionState()
    }

    override fun onGetSuggestions(results: Array<SuggestionsInfo>?) {
        if (results == null || !predictionsAllowed) return
        val result = results.firstOrNull() ?: return
        val wordForResult = pendingSpellWord
        val found = mutableListOf<String>()
        for (i in 0 until result.suggestionsCount.coerceAtMost(5)) {
            result.getSuggestionAt(i)?.let { found.add(it) }
        }

        if (wordForResult.isNotBlank()) {
            val connectionWord = currentInputConnection
                ?.getTextBeforeCursor(80, 0)?.toString()
                ?.takeLastWhile { it.isLetter() || it == '\'' }.orEmpty()

            if (connectionWord == wordForResult && found.isNotEmpty()) {
                suggestions = (listOf(wordForResult) + found).distinct().take(3).toMutableList()
                if (::suggestionRow.isInitialized) {
                    suggestionRow.post { renderSuggestions() }
                }
            }
        }
    }

    override fun onGetSentenceSuggestions(results: Array<SentenceSuggestionsInfo>?) {
        // Sentence-level suggestions are not used in this simple keyboard.
    }

    override fun onFinishInput() {
        super.onFinishInput()
        pendingSpellWord = ""
    }

    override fun onDestroy() {
        spellSession?.close()
        spellSession = null
        super.onDestroy()
    }

    private fun refreshLetterKeys() {
        // Recreate the keyboard view so shifted labels update.
        setInputView(onCreateInputView())
    }
}
