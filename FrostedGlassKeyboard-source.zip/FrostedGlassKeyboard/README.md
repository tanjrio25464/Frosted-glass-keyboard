# Frosted Glass Keyboard

A starter Android InputMethodService project for a translucent, rounded keyboard.

## What it includes
- QWERTY layout with shift, backspace, space, punctuation and enter
- Android spell-checker suggestions when the device has an English spell checker enabled
- A small offline next-word phrase list
- Dark/light styling based on the device's current system theme
- Prediction disabled in password and numeric input fields

## Important limitations
- This is starter source code, not a tested or signed APK.
- The spell checker is provided by Android/the device; it is not a custom AI model.
- Next-word prediction uses a small built-in phrase list, not personal learning.
- Android does not let a normal keyboard reliably sample and blur arbitrary app content behind it. The translucent panel is an approximation; actual blur depends on the OS and device.
- The `?123` and emoji keys are placeholders/simple actions and need further implementation for a full production keyboard.
- A custom keyboard can process anything typed into it. Review the source before enabling it. This project does not request internet permission and does not save or transmit typed text.

## Build
Open this folder in a compatible Android Studio installation, use JDK 17, and allow Gradle to sync. The project uses Android Gradle Plugin 8.10.1 and Kotlin 2.1.20. Mobile IDEs may not support these versions.

After installing the app:
1. Open Android Settings.
2. Find Keyboard list / On-screen keyboard / Manage keyboards (wording varies).
3. Enable Frosted Glass Keyboard.
4. Select it as the current keyboard.

Do not use it for sensitive typing until you have reviewed and tested it.
